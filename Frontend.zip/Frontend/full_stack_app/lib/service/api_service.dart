import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:full_stack_app/common/constants.dart';

class ApiService {

  static getDataFromDb(
    String firstName,
    String lastName,
    String designation,
    String emailId,
    String password,
    String mobileNumber
  ) async {
    var request = Dio(BaseOptions(
      baseUrl: "${Constants.baseUrl}/users",
      method: "POST",
      contentType: "application/json"      
    ));

    var response = await request.post("https://mongodbrepository.onrender.com/users", data: {
      "firstName": firstName,
      "lastName": lastName,
      "designation": designation,
      "emailId": emailId,
      "password": password,
      "mobileNumber": mobileNumber
    });

    if(response.statusCode == 200) {
      var bodyResponse = response.data;
      print("Body: $bodyResponse");
      var jsonData = jsonDecode(bodyResponse);
      print("Json: $jsonData");
      return jsonData;
    }
  }
}
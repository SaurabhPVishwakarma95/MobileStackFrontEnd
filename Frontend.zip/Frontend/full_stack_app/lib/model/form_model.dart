class FormModel {
  String? id;
  String? firstName;
  String? lastName;
  String? designation;
  String? emailId;
  String? password;
  String? mobileNumber;

  FormModel({
    required String firstName,
    required String lastName,
    required String designation,
    required String emailId,    
    required String password,
    required String mobileNumber,
  });  

  FormModel copyWith({
    String? id,
    String? firstName,
    String? lastName,
    String? designation,
    String? emailId,
    String? password,
    String? mobileNumber
  }) {
    return FormModel(
      firstName: firstName ?? this.firstName!, 
      lastName: lastName ?? this.lastName!, 
      designation: designation ?? this.designation!, 
      emailId: emailId ?? this.emailId!, 
      password: password ?? this.password!, 
      mobileNumber: mobileNumber ?? this.mobileNumber!
    );
  } 
}
class Constants {
  static String baseUrl = "https://mongodbrepository.onrender.com";
}
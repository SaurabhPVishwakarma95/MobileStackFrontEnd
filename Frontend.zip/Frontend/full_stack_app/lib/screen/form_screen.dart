import 'package:flutter/material.dart' hide FormState;
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:full_stack_app/bloc/form_bloc.dart';
import 'package:full_stack_app/bloc/form_event.dart';
import 'package:full_stack_app/bloc/form_state.dart';

class FormScreen extends StatefulWidget {
  const FormScreen({super.key});

  @override
  State<FormScreen> createState() => _FormScreenState();
}

class _FormScreenState extends State<FormScreen> {
  @override
  Widget build(BuildContext context) {

    var firstName = TextEditingController();
    var lastName = TextEditingController();
    var designation = TextEditingController();
    var emailId = TextEditingController();
    var password = TextEditingController();
    var mobileNumber = TextEditingController();

    var blocUIForm = context.read<FormBloc>();

    return Scaffold(    
      appBar: AppBar(title: Center(child: Text("Sign Up", style: TextStyle(color: Colors.white),)), backgroundColor: Colors.blue.shade700,),
      body: BlocListener<FormBloc, FormState>(
        listener: (context, state) => print("State: $state"),
        listenWhen: (previous, current) {return true;},
          child: BlocBuilder<FormBloc, FormState>(builder: (context, state) {
            if(state is FormStateSubmitting) {
              return CircularProgressIndicator();
            } else if(state is FormStateSuccess) {
              return Text("Data Submitted to Server Database");
            }
            return SingleChildScrollView(
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height,
                child: Column(
                    children: [
                      // SizedBox(height: 30),   
                      Expanded(
                        child: Form(
                          child: Container(
                            height: MediaQuery.of(context).size.height,
                            margin: EdgeInsets.all(8.0),
                            child: Column(
                              children: [
                                SizedBox(
                                  height: 50,
                                ),                      
                                TextField(
                                  decoration: InputDecoration(
                                    border: OutlineInputBorder(),
                                    hint: Text("Enter First Name")
                                  ),
                                  controller: firstName,
                                ),
                                SizedBox(
                                  height: 50,
                                ),
                                TextField(                        
                                  decoration: InputDecoration(
                                    border: OutlineInputBorder(),
                                    hint: Text("Enter Last Name")
                                  ),
                                  controller: lastName,
                                ),
                                SizedBox(
                                  height: 50,
                                ),
                                TextField(                        
                                  decoration: InputDecoration(
                                    border: OutlineInputBorder(),
                                    hint: Text("Enter Designation")
                                  ),
                                  controller: designation,
                                ),
                                SizedBox(
                                  height: 50,
                                ),
                                TextField(                        
                                  decoration: InputDecoration(
                                    border: OutlineInputBorder(),
                                    hint: Text("Enter Email Id")
                                  ),
                                  controller: emailId,
                                ),
                                SizedBox(
                                  height: 50,
                                ),
                                TextField(
                                  obscureText: true,
                                  decoration: InputDecoration(
                                    border: OutlineInputBorder(),
                                    hint: Text("Enter Password")
                                  ),
                                  controller: password,
                                ),
                                SizedBox(
                                  height: 50,
                                ),
                                TextField(                        
                                  decoration: InputDecoration(
                                    border: OutlineInputBorder(),
                                    hint: Text("Enter Mobile Number")
                                  ),
                                  controller: mobileNumber,
                                ),
                                SizedBox(
                                  height: 50,
                                ),
                                ElevatedButton(
                                  onPressed: () {
                                    blocUIForm.add(
                                      SubmitEvent(
                                        firstName: firstName.text, 
                                        lastName: lastName.text, 
                                        designation: designation.text, 
                                        emailId: emailId.text, 
                                        password: password.text, 
                                        mobileNumber: mobileNumber.text
                                      )
                                    );
                                  },
                                  child: Text("Submit")
                                )
                              ],
                            ),
                          )),
                      )
                    ],
                  ),
              ),
            );    
          },
        ),
      ),
    );
  }
}
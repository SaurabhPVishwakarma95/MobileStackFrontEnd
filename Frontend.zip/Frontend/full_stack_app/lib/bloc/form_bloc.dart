import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:full_stack_app/bloc/form_event.dart';
import 'package:full_stack_app/bloc/form_state.dart';
import 'package:full_stack_app/service/api_service.dart';

class FormBloc extends Bloc<FormEvent, FormState> {
  FormBloc(): super(FormStateInitial()) {
    on<SubmitEvent>((event, emit) async {
      await ApiService.getDataFromDb(event.firstName, event.lastName, event.designation, event.emailId, event.password, event.mobileNumber);
    });
  }
}

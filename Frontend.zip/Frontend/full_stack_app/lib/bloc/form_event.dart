abstract class FormEvent {}

class SubmitEvent extends FormEvent {
  var firstName, lastName, designation, emailId, password, mobileNumber;

  SubmitEvent({
    required this.firstName,
    required this.lastName,
    required this.designation,
    required this.emailId,
    required this.password,
    required this.mobileNumber
  });

}
abstract class FormState {}

class FormStateInitial extends FormState {}

class FormStateSubmitting extends FormState {}

class FormStateSuccess extends FormState {}